export const TopBanner = () => {
    return (
        <div>
            <div className="grid">
                <div>

                </div>
                <div>
                    <h3>View Saved Recipes</h3>
                    <p>See a recipe you like? </p>
                </div>
            </div>
            <div>

            </div>
        </div>
    )
}