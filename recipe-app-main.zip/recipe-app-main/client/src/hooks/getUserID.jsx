export const getUserID = () => {
    return (
            window.localStorage.getItem("userID")
    )
}