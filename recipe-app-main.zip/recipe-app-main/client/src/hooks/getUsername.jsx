export const getUsername = () => {
    return (
            window.localStorage.getItem("username")
    )
}