<div>

<h1>Smoothie Queen</h1>
<h6>A recipe website</h6>

<h4>About the project:</h4>
<p>Find, save, and create you favorite smoothie recipes. Features the ability to create an account, edit saves, and create a shopping list.</p>

<h4>Link to live site:</h4>
<a href="https://oliver-smoothie-queen.netlify.app/" target="_blank">click here</a>

<h4>Tech stack:</h4>
<p>
HTML,
CSS,
Tailwind,
Javascript,
React,
Express,
Node.js,
MongoDB
</p>

<h4>Project preview</h4>
<p>Home page:</p>
<img width="500" src="https://kylieoliver.com/smoothie-queen.png"/>
  
</div>
